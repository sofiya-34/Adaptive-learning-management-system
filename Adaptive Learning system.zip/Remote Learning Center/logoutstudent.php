<?php
session_start();

// Check if the session variable "sidx" is set
if (isset($_SESSION["sidx"])) {
    unset($_SESSION["sidx"]); // Unset the "sidx" session variable
}

// Redirect to the index page
header('Location: index');
exit(); // Always a good practice to call exit after a header redirect
?>
