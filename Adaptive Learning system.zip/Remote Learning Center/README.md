# CloudClassroom-PHP-Project
The “Cloud Classroom” Website (web-based application) is useful for the students, faculty, guest whoever likes to learn from web using E-Learn (Videos), as well Check result, schedules of assessment and all that task like event, news, students can find out list of fresh courses offered by them and admission procedure, discussion forum, fee structure etc. without going to institute. It provides the facility to the students or guest to have complete information about the institute. In this application, the student can attend his\her missed classes from e-learn.



@@@@@ HOW TO RUN THIS PROJECT @@@@@

Step 1: Download XAMPP in your system (Windows / Linux) ( Link: https://www.apachefriends.org/download.html )

Step 2: Run XAMPP Module (Apache & MySQL)

Step 3: Open browser and enter in URL "localhost/phpmyadmin" without quote.

Step 4: Create a Datebase named "cc_db" without quote.

Step 5: Import "cc_db.sql" File into database you just created. (you we'll find that file in Database/ folder above code.`

Step 6: Copy & Paste all file listed above into htdocs by creating a separate folder.

Step 7: Open Browser and enter in URL bar "localhost/<folder_name>" without quotes.

Done!

if you still need help. don't shy to ask, I'll happy to help you.

Email: connect@vishalmathur.in & MathurVishal@outlook.com
